/*
  Back-end for stillestående overskrift
*/

var header = document.getElementById("myHdr");
var sticky = header.offsetTop;

// Definer scroll-rutinen direkte
window.onscroll = function() {
    if (window.pageYOffset > sticky) {
        header.classList.add('sticky');
    } else {
        header.classList.remove('sticky');
    }
}