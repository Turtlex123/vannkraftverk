var xValues = ["Mandag","Tirsdag","Onsdag","Torsdag","Fredag","Lørdag","Søndag"];

new Chart("myChart", {
  type: "line",
  data: {
    labels: xValues,
    datasets: [{
      data: [860,1140,1060,1060,1070,1110,1330],
      borderColor: "#4f81bd",
      fill: false,
    }]
  },
  options: {
    legend: {display: false}
  }
});